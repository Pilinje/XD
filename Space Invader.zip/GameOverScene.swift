//
//  GameOverScene.swift
//  Solo micion
//
//  Created by Alejandro Vila Casahonda on 28/08/24.
//

import SpriteKit

var gameScore = 0
var highScoreNumber = 0

class GameOverScene: SKScene {

    let restartLabel = SKLabelNode(fontNamed: "Pixel-Regular")
    
    override func didMove(to view: SKView) {
        // Configuración del fondo
        let background = SKSpriteNode(imageNamed: "background")
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        background.zPosition = 0
        self.addChild(background)
        
        // Título "Game Over"
        let gameOverLabel = SKLabelNode(fontNamed: "Pixel-Regular")
        gameOverLabel.text = "Game Over"
        gameOverLabel.fontSize = 200
        gameOverLabel.fontColor = SKColor.white
        gameOverLabel.position = CGPoint(x: self.size.width * 0.5, y: self.size.height * 0.7)
        gameOverLabel.zPosition = 1
        self.addChild(gameOverLabel)
        
        // Etiqueta de puntuación
        let scoreLabel = SKLabelNode(fontNamed: "Pixel-Regular")
        scoreLabel.text = "Score: \(gameScore)"
        scoreLabel.fontSize = 125
        scoreLabel.fontColor = SKColor.white
        scoreLabel.position = CGPoint(x: self.size.width / 2, y: self.size.height * 0.55)
        scoreLabel.zPosition = 1
        self.addChild(scoreLabel)
        
        // Verificar y actualizar la puntuación más alta (High Score)
        let defaults = UserDefaults.standard
        highScoreNumber = defaults.integer(forKey: "HighScoreSaved")
        
        if gameScore > highScoreNumber {
            highScoreNumber = gameScore
            defaults.set(highScoreNumber, forKey: "HighScoreSaved")
        }
        
        // Etiqueta de puntuación más alta
        let highScoreLabel = SKLabelNode(fontNamed: "Pixel-Regular")
        highScoreLabel.text = "High Score: \(highScoreNumber)"
        highScoreLabel.fontSize = 125
        highScoreLabel.fontColor = SKColor.white
        highScoreLabel.position = CGPoint(x: self.size.width / 2, y: self.size.height * 0.45)
        highScoreLabel.zPosition = 1
        self.addChild(highScoreLabel)
        
        // Etiqueta para reiniciar el juego
        restartLabel.text = "Restart"
        restartLabel.fontSize = 90
        restartLabel.fontColor = SKColor.white
        restartLabel.zPosition = 1
        restartLabel.position = CGPoint(x: self.size.width / 2, y: self.size.height * 0.3)
        self.addChild(restartLabel)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let pointOfTouch = touch.location(in: self)
            
            if restartLabel.contains(pointOfTouch) {
                let sceneToMoveTo = GameScene(size: self.size)
                sceneToMoveTo.scaleMode = self.scaleMode
                let myTransition = SKTransition.fade(withDuration: 0.5)
                self.view?.presentScene(sceneToMoveTo, transition: myTransition)
            }
        }
    }
}
